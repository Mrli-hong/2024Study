# Extension Manager
Call Extension function at Node.js 