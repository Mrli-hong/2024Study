# Node Test server
warning: If the root directory exists,`package.json` dependencies need added to root `package.json`

need `yarn` globally

# Debug Test Server 

1. Run Test Server in this directory
```shell
yarn dev
```
2. Run the core system in root directory

```shell
yarn start
```