/* SystemJS module definition */
interface Window {
  process: any;
  requirejs: any;
  require: any;
  angular: any;
  electron: any;
}
