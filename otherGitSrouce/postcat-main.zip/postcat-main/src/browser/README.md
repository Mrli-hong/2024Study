# Postcat Workbench

Postcat browser code

# Run

| Command      | Desc                              |
| ------------ | --------------------------------- |
| `yarn start` | Only run frontend,local workspace |
| `yarn serve` | Use proxy                         |
| `yarn build` | Pack static frontend resource     |
