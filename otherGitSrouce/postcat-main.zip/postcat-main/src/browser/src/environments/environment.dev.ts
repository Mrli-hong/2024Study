import { COMMON_CONFIG } from 'pc/browser/src/environments/common.constant';
export const APP_CONFIG = {
  serverUrl: 'http://52.76.76.88:8080',
  production: false,
  environment: 'DEV',
  ...COMMON_CONFIG
};
