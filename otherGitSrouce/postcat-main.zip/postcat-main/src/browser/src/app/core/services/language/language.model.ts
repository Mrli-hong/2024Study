export const LANGUAGES = [
  {
    name: 'English',
    value: 'en-US',
    path: 'en'
  },
  {
    name: '简体中文',
    value: 'zh-Hans',
    path: 'zh'
  }
];
