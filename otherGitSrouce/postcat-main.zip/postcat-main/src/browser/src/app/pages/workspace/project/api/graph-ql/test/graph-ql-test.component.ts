import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'eo-graph-ql-test',
  templateUrl: './graph-ql-test.component.html',
  styleUrls: ['./graph-ql-test.component.scss']
})
export class GraphQlTestComponent {
  constructor() {}
}
