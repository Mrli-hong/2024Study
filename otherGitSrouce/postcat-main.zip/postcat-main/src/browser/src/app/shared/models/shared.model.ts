export const REQURIED_ENUMS = [
  { title: $localize`Yes`, value: 1 },
  { title: '-', value: 0 }
];
