export const PROTOCOL = 'eoapi://';
