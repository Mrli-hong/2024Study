export const MODAL_NORMAL_SIZE: number = 900;
export const MODAL_SMALL_SIZE: number = 600;
export const MODAL_LARGE_SIZE: number = 1200;
