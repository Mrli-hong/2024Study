export const defaultExtensions = ['postcat-export-openapi', 'postcat-import-openapi', 'postcat-basic-auth'];
