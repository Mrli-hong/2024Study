/** disable extensions */
export const DISABLE_EXTENSION_NAMES = 'DISABLE_EXTENSION_NAMES';

/** is show local data source tips */
export const IS_SHOW_REMOTE_SERVER_NOTIFICATION = 'IS_SHOW_REMOTE_SERVER_NOTIFICATION';
