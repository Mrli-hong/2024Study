import { Component } from '@angular/core';

@Component({
  selector: 'pc-console',
  template: `<pc-debug-theme></pc-debug-theme>`,
  styleUrls: ['./pc-console.component.scss']
})
export class PcConsoleComponent {
  constructor() {}
}
