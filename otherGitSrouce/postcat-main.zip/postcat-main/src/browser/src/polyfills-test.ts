import 'zone.js';
/***************************************************************************************************
 * global is required by default
 */
(window as any).global = window; // Included with Angular CLI.

/***************************************************************************************************
 * APPLICATION IMPORTS
 */
