## Contributing

First off, thank you for considering contributing to Postcat. It's people
like you that make Postcat such a great tool.

## Contributing Guide
* [中文](https://github.com/Postcatlab/postcat/wiki/%E8%B4%A1%E7%8C%AE%E8%80%85%E6%8C%87%E5%8D%97)
* English